package finalP;
public class CaptainAmerica extends Superhero{

	//Default or explicit Constructor
    CaptainAmerica(){
	}
	//Parameterized or implicit Constructor
    CaptainAmerica(String name, String power, int HP){
		super(name,power,HP);
    //using the 'super' keyword for inheritance
    }
    void showHero() {
		System.out.println("Name: " + name );
		System.out.println("Power: " + power);
		System.out.println("HP: " + HP);
	} 
   //overriding method
    void sayLines() {
		System.out.println("I Am Steve Rogers Also Known As 'CaptinAmerica',");
		System.out.println("Avengers...assemble!");
    }
}
