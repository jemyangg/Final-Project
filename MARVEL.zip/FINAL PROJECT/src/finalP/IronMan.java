package finalP;
public class IronMan extends Superhero{

	//Default or explicit Constructor
	IronMan(){
	}
	//Parameterized or implicit Constructor
    IronMan(String name, String power, int HP){
    	this.name = name;
    	this.power = power;
    	this.HP = HP;
    }
    //method overriding
    void showHero() {
		System.out.println("Name: " + name );
		System.out.println("Power: " + power);
		System.out.println("HP: " + HP);
	}
    void sayLines() {
    	System.out.println("I Am Tony SHark Also Known As 'IronMan'.");
    	System.out.println("The Truth Is I Am Iron Man. The Suit And I Are One.");  	
    }
}


