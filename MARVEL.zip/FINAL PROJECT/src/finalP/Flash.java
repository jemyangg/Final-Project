package finalP;
public class Flash extends Superhero{

	//Default or explicit Constructor
	Flash(){
	}
	//Parameterized or implicit Constructor
    Flash(String name, String power, int HP){
    	super(name,power,HP);
    	//using the 'super' keyword for INHERITANCE
    }
    void showHero() {
		System.out.println("Name: " + name );
		System.out.println("Power: " + power);
		System.out.println("HP: " + HP);
	}
    //overriding method
    void sayLines() {
    	System.out.println("I Am Barry Allen Also Known As 'Flash',");
    	System.out.println("and I am The Fastest Man Alive!");
    }
   
}
	

