package finalP;

class Mystique extends Villain{
	private String name;
	private String power;
	private int HP;
	
	Mystique(){
	}
	
	void showStats(String name, String power, int HP) {
		this.name = name;
		this.power = power;
		this.HP = HP;
		System.out.println("Name: " + name);
		System.out.println("Power: " + power);
		System.out.println("HP: " + HP);
	}
	//GETTERS
	public String getName() {
		return name;
	}
	public String getPower() {
		return power;
	}
	public int getHP() {
		return HP;
	}
	//SETTERS
	public void setName(String name) {
		this.name = name;
	}
	public void setPower(String power) {
		this.power = power;
	}
	public void setHP(int HP) {
		this.HP = HP;
	}
	
	void showRage() {
		System.out.println("Don't You See? This Is Who You Were Meant To Be.");
		System.out.println("This Is You. No More Hiding.");
	}
}
