package finalP;

//ABSTRACTION(ABSTRACT CLASS & METHODS) SUPERCLASS
abstract class Villain {
	
	//fields or attributes
	 String name; 
	 String power;
	 int HP;
	
	 //abstract method w/out a body that needs to be overriden on the subclass Thanos & Mystique
	abstract void showRage();
	
}
