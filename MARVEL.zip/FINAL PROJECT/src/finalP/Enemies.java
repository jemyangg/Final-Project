package finalP;

//ABSTRACTION(INTERFACE)SUPERCLASS
public interface Enemies{
	
	//methods to be overriden on its subclasses: LOKI & ULTRON
	public void outrage();
	public void showStats();
}
