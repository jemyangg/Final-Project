package finalP;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
       
            JOptionPane.showMessageDialog(null, "Welcome User!", "MARVEL", JOptionPane.PLAIN_MESSAGE);
         //EXCEPTIONS
         try {
            int option = JOptionPane.showConfirmDialog(null, "Do you like Marvel?", "MARVEL", JOptionPane.YES_NO_OPTION);

            if (option == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(null, "Great! Let's get started, Marvelites.");

                //POLYMORPHISM
                String[] superheroOptions = {"IronMan", "CaptainAmerica", "Flash", "Hulk", "Spiderman"};
                String selectedSuperhero = (String) JOptionPane.showInputDialog(null,
                        "Choose a superhero:",
                        "MARVEL",
                        JOptionPane.PLAIN_MESSAGE,
                        null,
                        superheroOptions,
                        superheroOptions[0]);

                if (selectedSuperhero != null) {
                    switch (selectedSuperhero) {
                        case "IronMan":
                            showIronManDetails("IronMan", "PowerArmorSuit", 9);
                            break;
                        case "CaptainAmerica":
                            showCaptainAmericaDetails("CaptainAmerica", "Strength", 7);
                            break;
                        case "Flash":
                            showFlashDetails("Flash", "Speed", 7);
                            break;
                        case "Hulk":
                            showHulkDetails("Hulk", "Strength", 8);
                            break;
                        case "Spiderman":
                            showSpidermanDetails();
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Invalid choice.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
                //Asking the user to continue
                option = JOptionPane.showConfirmDialog(null, "Do you want to continue?", "MARVEL", JOptionPane.YES_NO_OPTION);

                if (option == JOptionPane.YES_OPTION) {

                	//here are the choices for the enemies/villain
                    String[] villainOptions = {"Thanos", "Mystique", "Loki", "Ultron"};
                    String selectedVillain = (String) JOptionPane.showInputDialog(null,
                            "Choose a villain/enemies:",
                            "MARVEL",
                            JOptionPane.PLAIN_MESSAGE,
                            null,
                            villainOptions,
                            villainOptions[0]);

                    if (selectedVillain != null) {
                        switch (selectedVillain) {
                            case "Thanos":
                                showThanosDetails("Thanos", "Invulnerable", 9);
                                break;
                            case "Mystique":
                                showMystiqueDetails("Mystique", "Shapeshifting", 8);
                                break;
                            case "Loki":
                                showLokiDetails("Loki");
                                break;
                            case "Ultron":
                                showUltronDetails("Ultron");
                                break;
                            default:
                                JOptionPane.showMessageDialog(null, "Invalid choice.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        JOptionPane.showMessageDialog(null, "Great Pair!");
                        JOptionPane.showMessageDialog(null, "________END________");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "An unexpected error occurred. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void showIronManDetails(String name, String power, int HP) {
        IronMan im = new IronMan(name, power, HP);
        im.showHero();
        im.sayLines();
    }

    private static void showCaptainAmericaDetails(String name, String power, int HP) {
        CaptainAmerica ca = new CaptainAmerica(name, power, HP);
        ca.showHero();
        ca.sayLines();
    }

    private static void showFlashDetails(String name, String power, int HP) {
        Flash f = new Flash(name, power, HP);
        f.showHero();
        f.sayLines();
    }

    private static void showHulkDetails(String name, String power, int HP) {
        Hulk h = new Hulk(name, power, HP);
        h.showHero();
        h.sayLines();
    }

    private static void showSpidermanDetails() {
        Spiderman sm = new Spiderman();
        sm.showHero();
        sm.sayLines();
    }

    private static void showThanosDetails(String name, String power, int HP) {
        Thanos t = new Thanos();
        t.showStats(name, power, HP);
        t.showRage();
    }

    private static void showMystiqueDetails(String name, String power, int HP) {
        Mystique m = new Mystique();
        m.showStats(name, power, HP);
        m.showRage();
    }

    private static void showLokiDetails(String name) {
        Loki l = new Loki();
        l.outrage();
        l.showStats();
    }

    private static void showUltronDetails(String name) {
        Ultron u = new Ultron();
        u.outrage();
        u.showStats();
    }
}
