package finalP;

public interface FlightAbility {
     void fly();
}
