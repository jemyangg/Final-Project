package finalP;

public interface TelepathyAbility {
     void mindReading();
}
