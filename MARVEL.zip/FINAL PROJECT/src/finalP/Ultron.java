package finalP;

class Ultron implements Enemies, FlightAbility, TelepathyAbility{
	String name = "ULTRON";
	
	//METHOD OVERRIDING
	public void outrage() {
		System.out.println("I Am " + name);
		System.out.println("What Doesn't Kill Me, Makes Me Stronger");
	}
	
	public void fly() {
		System.out.println("Flight Ability");
	}
	public void mindReading() {
		System.out.println("Telepathy Ability");
	}
	
	public void showStats() {
		System.out.println("Abilities: ");
		fly();
		mindReading();
	}
}
