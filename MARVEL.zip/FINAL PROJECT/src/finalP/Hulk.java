package finalP;
public class Hulk extends Superhero{

	//Default or explicit constructor
	Hulk(){
	}
	//Parameterized or implicit constructor
	Hulk(String name, String power, int HP){
		super(name,power,HP);
		//using the 'super' keyword for inheritance
	}
	void showHero() {
		System.out.println("Name: " + name);
		System.out.println("Power: " + power);
		System.out.println("HP: " + HP);
	}
	//overriding method
	void sayLines() {
		System.out.println("I Am Bruce Banner Also Know 'The Incredible Hulk'.");
		System.out.println("Don't Make Me Angry. You Wouldn't Like Me When I'm Angry.");
		System.out.println("Hulk Smashes!");
	}
}
