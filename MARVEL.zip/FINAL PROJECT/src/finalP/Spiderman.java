package finalP;
public class Spiderman extends Superhero{

	//Default or explicit Constructor
	Spiderman(){
	}
		
	//Parameterized or implicit Constructor
	Spiderman(String name, String power, int HP){
	   super(name,power,HP);
	//using the 'super' keyword for inheritance
	    }
	void showHero() {
			System.out.println("Name: " + name );
			System.out.println("Power: " + power);
			System.out.println("HP: " + HP);
	}
	void sayLines() {
		System.out.println("I Am Peter Benjamin Parker Also Known As 'Spiderman'.");
			System.out.println("With Great Power,There Must Also Come Great Responsibility.");
	}
}
