package finalP;

public class Loki implements Enemies, FlightAbility{

	String name = "LOKI";
	
	//method overriding
	public void outrage() {
		System.out.println("I Am " + name);
		System.out.println("Know This. You Cross Me, There Are Deadly Consequences");
	}
	
	public void fly() {
		System.out.println("Flight Ability");
	}
	
	public void showStats() {
		System.out.println("Ability: "); 
		fly();
	}
}
