package finalP;

class Thanos extends Villain{
	private String name;
	private String power;
	private int HP;
	
	Thanos(){
	}
	
	void showStats(String name, String power, int HP) {
		this.name = name;
		this.power = power;
		this.HP = HP;
		System.out.println("Name: " + name);
		System.out.println("Power: " + power);
		System.out.println("HP: " + HP);
	}
	//GETTERS
	public String getName() {
		return name;
	}
	public String getPower() {
		return power;
	}
	public int getHP() {
		return HP;
	}
	//SETTERS
	public void setName(String name) {
		this.name = name;
	}
	public void setPower(String power) {
		this.power = power;
	}
	public void setHP(int HP) {
		this.HP = HP;
	}
	
	//method overriding
	void showRage() {
		 System.out.println("I am Inevitable.");
		 System.out.println("You're Strong, But I Could Snap My Fingers And You'd All Cease To Exist.");
    }
}