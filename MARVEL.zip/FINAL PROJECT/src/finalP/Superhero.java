package finalP;
public class Superhero {

	//Fields & attributes(ENCAPSULATED)
	//ENCAPSULATION
	public String name;
	protected String power;
	protected int HP;
	
	//Default or explicit constructor
	Superhero(){
	}
	//Parameterized or implicit constructor
	Superhero(String name, String power, int HP) {
		this.name = name;
		this.power = power;
		this.HP = HP;
	}
	void showHero() {
		System.out.println("Hero");
	}
	void sayLines() {
		System.out.println("Hello");
	}
	
 }

